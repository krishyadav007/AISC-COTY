import streamlit as st
import keras
from PIL import Image, ImageOps
import cv2
import numpy as np
from streamlit_webrtc import VideoTransformerBase, webrtc_streamer

from streamlit_webrtc import webrtc_streamer
labels = ['pollution', 'vehicle']

def machine_classification(img, weights_file = 'model.h5'):
    # Load the model
    model = keras.models.load_model(weights_file)

    # Create the array of the right shape to feed into the keras model
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
    image = img
    #image sizing
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.ANTIALIAS)

    #turn the image into a numpy array
    image_array = np.asarray(image)
    # Normalize the image
    normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1

    # Load the image into the array
    data[0] = normalized_image_array

    # run the inference
    prediction = model.predict(data)
    # return prediction
    return np.argmax(prediction) # return position of the highest probability

def image_upload():

    uploaded_file = st.file_uploader("Choose a image")
    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption='Uploaded Image.', use_column_width=True)
        st.write("")
        st.write("Classifying...")
        label = machine_classification(image)
        # st.write(label)
        if label == 0:
            st.write("The image is of pollution")
        else:
            st.write("The image is of vehicle")

class VideoTransformer(VideoTransformerBase):
    def transform(self, frame):
        img = frame.to_ndarray(format="bgr24")
        im = Image.fromarray(np.uint8(img))
        text = machine_classification(im)
        # font
        font = cv2.FONT_HERSHEY_SIMPLEX        
        # org
        org = (50, 50)
        # fontScale
        fontScale = 1
        # Blue color in BGR
        color = (255, 0, 0)
        # Line thickness of 2 px
        thickness = 2
        # Using cv2.putText() method
        img = cv2.putText(img, str(labels[text]), org, font, fontScale, color, thickness, cv2.LINE_AA)
        return img

def live_footage():
    webrtc_streamer(key="example", video_transformer_factory=VideoTransformer)

def main():
    st.title("Convolution Neural Network Algorithms for Enhanced Detection of Vehicle Exhaust Pollution.")
    st.header("By Krish Yadav")
    menu = ["Upload","Live","Train"]
    choice = st.sidebar.selectbox("Menu",menu)

    if choice == "Upload":
        st.subheader("Upload image for testing")
        image_upload()

    elif choice == "Live":
        st.subheader("Live stream testing")
        live_footage()

    elif choice == "Train":
        st.subheader("Train")
        st.markdown('Please visit the following notebook for training')
        st.markdown('[CLICK HERE](https://www.kaggle.com/keagle/coty-classifier-model)')
        st.markdown('You can download the h5 file of CNN trained and replace it in this folder if you want.')

if __name__ == "__main__":
    main()